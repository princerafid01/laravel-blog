<?php $__env->startSection('recent_blog'); ?>

	<h4>Recent Post</h4>
	<ul class="templatemo_list">
	    <?php $__currentLoopData = $recent_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <li><a href="<?php echo e(URL::to('/blog-detail/'.$blog->blog_id)); ?>"><?php echo e($blog->blog_title); ?></a></li>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>