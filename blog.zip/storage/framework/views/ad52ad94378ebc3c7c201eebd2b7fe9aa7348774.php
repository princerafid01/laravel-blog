<?php $__env->startSection('admin_main_content'); ?>
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">Library</a></li>
  <li class="active">Data</li>
</ol>
  	<h3 style="font-family: cursive" class="bg-success text-success text-center">
		<?php if(Session::has('message')): ?>
		<?php echo e(session('message')); ?>

		<?php endif; ?>
  		
  	</h3>



<table class="table"> 
	<h1 class="text-center">Comments</h1>
	<thead> 
		<tr> 
			<th>#</th> 
			<th>Blog title</th> 
			<th>User Name</th> 
			<th>Comments</th> 
			<th>Publication status</th> 
			<th>Action</th>
		</tr> 
	</thead> 
	<tbody> 
		<?php 

			$i = 1;
		?>
			<?php $__currentLoopData = $all_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($comment->parent_id == 0): ?>
		<tr> 
			<th scope="row"><?php echo e($i++); ?></th> 
			<td><?php echo e($comment->blog_title); ?></td>  
			<td><?php echo e($comment->name); ?></td>  
			<td><?php echo e($comment->comments); ?></td>  
			<td <?php echo e(($comment->publication_status == 1) ? "":"style=color:red"); ?>><?php echo e(($comment->publication_status == 1) ? "Published" : "Unpublished"); ?> </td> 
			<td> 
				<?php if($comment->publication_status == 1): ?>
				<a href="<?php echo e(URL::to('/unpublish-comment/'.$comment->comment_id)); ?>" class="btn btn-primary">Unpublish</a>
				<?php else: ?> 
				<a href="<?php echo e(URL::to('/publish-comment/'.$comment->comment_id)); ?>" class="btn btn-primary">Publish</a> 
				<?php endif; ?>
			</td>

		</tr> 
		<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody> 
</table>


<table class="table"> 
	<h1 class="text-center">Replies</h1>
	<thead> 
		<tr> 
			<th>#</th> 
			<th>Blog title</th> 
			<th>User Name</th> 
			<th>Replies</th> 
			<th>Publication status</th> 
			<th>Action</th>
		</tr> 
	</thead> 
	<tbody> 
		<?php 

			$i = 1;
		?>
			<?php $__currentLoopData = $all_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($comment->parent_id != 0): ?>
		<tr> 
			<th scope="row"><?php echo e($i++); ?></th> 
			<td><?php echo e($comment->blog_title); ?></td>  
			<td><?php echo e($comment->name); ?></td>  
			<td><?php echo e($comment->comments); ?></td>  
			<td <?php echo e(($comment->publication_status == 1) ? "":"style=color:red"); ?>><?php echo e(($comment->publication_status == 1) ? "Published" : "Unpublished"); ?> </td> 
			<td> 
				<?php if($comment->publication_status == 1): ?>
				<a href="<?php echo e(URL::to('/unpublish-comment/'.$comment->comment_id)); ?>" class="btn btn-primary">Unpublish</a>
				<?php else: ?> 
				<a href="<?php echo e(URL::to('/publish-comment/'.$comment->comment_id)); ?>" class="btn btn-primary">Publish</a> 
				<?php endif; ?>
			</td>

		</tr> 
		<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody> 
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>