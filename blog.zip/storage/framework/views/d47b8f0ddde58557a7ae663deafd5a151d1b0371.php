@extend('master')
<?php $__env->startSection('main_content'); ?>

<div id="templatemo_content">
<div class="post_section">

	<div class="post_date">
    	30<span>Nov</span>
	</div>
    <div class="post_content">
    
        <h2><?php echo e($blog_info->blog_title); ?></h2>
        
    	<strong>Author:</strong> <?php echo e($blog_info->admin_name); ?> | <strong>Category:</strong> <a href="<?php echo e(URL::to('/category-blog/'.$blog_info->category_id)); ?>"><?php echo e($blog_info->category_name); ?></a>
        
        <a href="#"><img src="<?php echo e(asset($blog_info->blog_image)); ?>" alt="Templates" /></a>
        
        <p><?php echo e($blog_info->long_description); ?></p>


<div class="comment_tab">
            <?php echo e(count($all_comments)); ?> Comments
        </div>

<?php $__currentLoopData = $all_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="comment_section">
    <ol class="comments first_level">
            
            <li>
                <div class="comment_box commentbox1">
                        
                    <div class="gravatar">
                        <img src="<?php echo e(asset('images/avator.png')); ?>" alt="author 6" />
                    </div>
                    
                    <div class="comment_text">
                        <div class="comment_author"><?php echo e($comment->name); ?> <span class="date time"><?php echo e(date('M j , Y g:i A',strtotime($comment->created_at))); ?></span></div>
                        <p><?php echo e($comment->comments); ?></p>
    <?php if(Auth::user() != Null): ?>

                      <div class="reply"><a href="#" class="reply" id="<?php echo e($comment->comment_id); ?>">Reply</a></div>
    <?php endif; ?>
                    </div>
                    <div class="cleaner"></div>
                </div>                        
                
            </li>

            

            <li class="reply-comment">
                	<ol class="comments">
                            
                
                <?php $__currentLoopData = $reply_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($reply->parent_id == $comment->comment_id): ?>
                        <li>
                            <div class="comment_box commentbox2">
                            
                            <div class="gravatar">
                            <img src="<?php echo e(asset('images/avator.png')); ?>" alt="author 5" />
                            </div>
                            <div class="comment_text">
                            <div class="comment_author"><?php echo e($reply->name); ?> <span class="date time"><?php echo e(date('M j , Y g:i A',strtotime($reply->created_at))); ?></span> </div>
                            <p><?php echo e($reply->comments); ?></p>
                            
                            
                            <div class="cleaner"></div>
                            </div>                        
                        
                        
                        </li>


<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                

    <?php if(Auth::user() != Null): ?>


<li class="reply-form <?php echo e($comment->comment_id); ?>" id="<?php echo e($comment->comment_id); ?>">                        
    <div id="comment_form">
        <h3>Leave a reply</h3>
        
        <?php echo Form::open(['url' => '/save-comments-reply', 'method' => 'post']); ?>

            
            
            <div class="form_row">
                <label>Your reply</label><br />
                <textarea  name="comments" rows="5" cols="15"></textarea>
                <input type="hidden" name="blog_id" value="<?php echo e($blog_info->blog_id); ?>" />
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" />
                <input type="hidden" name="parent_id" value="<?php echo e($comment->comment_id); ?>" />
                <input type="hidden" id="reply_id" value="<?php echo e($reply->comment_id); ?>" />
            </div>

            
            <?php echo Form::submit('Submit' , ['name' => 'submit' , 'class' => 'submit_btn']); ?>

        <?php echo Form::close(); ?>        
        
    </div>
</li>
<?php endif; ?>



                        
                    </ol>  
			</li> 




        </ol>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(Auth::user() != Null): ?>


      	<h3 style="font-family: cursive" class="bg-success text-success text-center">
 
    		<?php if(Session::has('message')): ?>
    			<?php echo e(session('message')); ?>

    		<?php endif; ?>
      		
      	</h3>

        
    	<div id="comment_form">
        <h3>Leave a comment</h3>
        
        <?php echo Form::open(['url' => '/save-comments', 'method' => 'post']); ?>

            
            
            <div class="form_row">
                <label>Your comment</label><br />
                <textarea  name="comments" rows="" cols=""></textarea>
                <input type="hidden" name="blog_id" value="<?php echo e($blog_info->blog_id); ?>" />
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" />

            </div>

            
            <?php echo Form::submit('Submit' , ['name' => 'submit' , 'class' => 'submit_btn']); ?>

		<?php echo Form::close(); ?>        
        
    </div>
    <?php else: ?>
<div class="comment_tab">
    <h3>Please <a href="<?php echo e(URL::to('/login')); ?>">login </a> or <a href="<?php echo e(URL::to('/register')); ?>">register</a> to comment or to give reply.</h3>
        </div>

    <?php endif; ?>
    
	</div>

    <div class="cleaner"></div>
    
</div>
</div>
<?php $__env->stopSection(); ?>