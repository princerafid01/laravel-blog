<?php $__env->startSection('category'); ?>

    <h4>Categories</h4>
    <ul class="templatemo_list">
    	
        
        
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>