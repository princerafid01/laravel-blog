<?php $__env->startSection('admin_main_content'); ?>
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">Library</a></li>
  <li class="active">Data</li>
</ol>
  	<h3 style="font-family: cursive" class="bg-success text-success text-center">
  		<?php 
			// $message = Session::get('message');
			// if($message){
			// 	echo $message;
			// 	Session::put('message', '');
			// }
  		?>
		<?php if(Session::has('message')): ?>
		<?php echo e(session('message')); ?>

		<?php endif; ?>
  		
  	</h3>

<table class="table"> 
	<caption></caption>
	<thead> 
		<tr> 
			<th>#</th> 
			<th>Category Name</th> 
			<th>Publication status</th> 
			<th>Action</th> 
			<th>Label</th> 
		</tr> 
	</thead> 
	<tbody> 
		<?php 

			$i = 1;
		?>
			<?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr> 
			<th scope="row"><?php echo e($i++); ?></th> 
			<td><?php echo e($category->category_name); ?></td>  
			<td <?php echo e(($category->publication_status == 1) ? "":"style=color:red"); ?>><?php echo e(($category->publication_status == 1) ? "Published" : "Unpublished"); ?> </td> 
			<td> 
				<?php if($category->publication_status == 1): ?>
				<a href="<?php echo e(URL::to('/unpublish-category/'.$category->category_id)); ?>" class="btn btn-primary">Unpublish</a>
				<?php else: ?> 
				<a href="<?php echo e(URL::to('/publish-category/'.$category->category_id)); ?>" class="btn btn-primary">Publish</a> 
				<?php endif; ?>
			</td>
			<td> 
				<a href="<?php echo e(URL::to('/edit-category/'.$category->category_id)); ?>" class="btn btn-primary">Edit</a> 
				<a href="<?php echo e(URL::to('/delete-category/'.$category->category_id)); ?>" class="btn btn-primary" onclick="return confirm('Are you sure')">Delete</a> 
			</td> 

		</tr> 
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody> 
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>