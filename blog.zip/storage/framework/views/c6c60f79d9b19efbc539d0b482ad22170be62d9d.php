<?php $__env->startSection('title','edit blog'); ?>
<?php $__env->startSection('admin_main_content'); ?>
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">Library</a></li>
  <li class="active">Data</li>
</ol>

  	<h3 style="font-family: cursive" class="bg-success text-success text-center">
  		<?php 
			// $message = Session::get('message');
			// if($message){
			// 	echo $message;
			// 	Session::put('message', '');
			// }
  		?>
		<?php if(Session::has('message')): ?>
		<?php echo e(session('message')); ?>

		<?php endif; ?>
  		
  	</h3>
<?php echo e(Form::open(['class' => "form-horizontal" , 'url' => '/edited-blog','method' => 'post' , 'enctype' => 'multipart/data-form', 'files' => true])); ?>


  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Blog Title</label>
    <div class="col-sm-10">
      <input type="text" name="blog_title" class="form-control" id="inputEmail3" value="<?php echo e($blog->blog_title); ?>">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Blog Category</label>
    <div class="col-sm-10">
      <select class="form-control" name="category_id" id="">
        <option value="">Select Blog Category</option>

        <?php $__currentLoopData = $all_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($cat->category_id); ?>" 
            <?php echo e(($cat->category_id == $blog->category_id) ? 'selected' : ''); ?>

            ><?php echo e($cat->category_name); ?></option>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Short Description</label>
    <div class="col-sm-10">
    	<textarea name="short_description" class="form-control" id="" cols="30" rows="10"><?php echo e($blog->short_description); ?> </textarea>
    </div>
  </div>

  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Long Description</label>
    <div class="col-sm-10">
      <textarea name="long_description" class="form-control" id="" cols="30" rows="10"> <?php echo e($blog->long_description); ?> </textarea>
    </div>
  </div>


  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Blog image</label>
    <div class="col-sm-10">
      <img src="<?php echo e(asset($blog->blog_image)); ?>" alt="<?php echo e($blog->blog_image); ?>">
      <input type="file" name="blog_image">
    </div>
  </div>

  <div class="form-group">
  	<label for="inputPassword3" class="col-sm-2 control-label">Publiction status</label>
    <div class="col-sm-10">
    	<select class="form-control" name="publication_status" id="">
        <option value="0" <?php echo e(($blog->publication_status == 0) ? 'selected' : ''); ?>>Unpublished</option>
        <option value="1" <?php echo e(($blog->publication_status == 1) ? 'selected' : ''); ?>>Published</option>
    	</select>
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-success">Add blog post</button>
    </div>
  </div>
  <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>