 @extend('master')
 <?php $__env->startSection('main_content'); ?>

        	<div id="templatemo_content">
        
    		<div class="post_section">
            
            	<div class="post_date">
                	30<span>Nov</span>
            	</div>
<div class="post_content">
                
                    <h2><a href="blog_post.html">Aliquam lorem ante dapibus</a></h2>

                    <strong>Author:</strong> Steven | <strong>Category:</strong> <a href="#">PSD</a>, <a href="#">Templates</a>
                    
                    <a href="http://www.templatemo.com/page/1" target="_parent"><img src="images/templatemo_image_01.jpg" alt="image" /></a>
                    
                    <p><a href="http://www.templatemo.com" target="_parent">Red Blog </a> is a free HTML/CSS layout from templatemo.com for everyone. There are total 5 pages included (blog, <a href="blog_post.html">full  post</a>, services, portfolio, contact) Quisque at ante sit amet erat laoreet fermentum. Quisque nec nisl.</p>
                    <p>Fusce lacinia orci at nisi. Suspendisse at nisi nec diam pretium tincidunt. Ut vitae felis eu lectus ultrices varius. Aliquam lacus turpis, dapibus eget, tincidunt eu, lobortis et, magna. Integer pellentesque dignissim diam. </p>
                    <p><a href="blog_post.html">24 Comments</a> | <a href="blog_post.html">Continue reading...</a>                </p>
</div>
                <div class="cleaner"></div>
            </div>
                
            <div class="post_section">
                    
                
            
              
              
              	<div class="post_date">
                	24<span>Oct</span>
            	</div>
                
                <div class="post_content">
                	<h2><a href="blog_post.html">Lorem ipsum dolor sit amet</a></h2>
                	<strong>Author:</strong> Templatemo <strong>Category:</strong> <a href="#">HTML</a>, <a href="#">CSS</a>
                
                	<a href="http://www.templatemo.com/page/2" target="_parent"><img src="images/templatemo_image_02.jpg" alt="image" /></a>
                
                	<p>Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow">XHTML</a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow">CSS</a>. Credits go to <a href="http://www.photovaco.com" target="_blank">free photos</a> for photos, <a href="http://www.smashingmagazine.com/2008/09/23/practika-a-free-icon-set/" target="_blank">Smashing Magazine</a> for icons and <a href="http://www.brusheezy.com" target="_blank">Nose-Meat</a> and <a href="http://www.brusheezy.com" target="_blank">FortuneGfx</a> for brushes. Phasellus cursus lobortis arcu. Donec scelerisque. Integer ultrices. Vivamus eu tortor. Phasellus tempus, justo et laoreet varius, odio mi ultrices libero, nec faucibus dui felis eu dui. Cras ac odio ac mi imperdiet sollicitudin.</p>
               	  <a href="blog_post.html">58 Comments</a> | <a href="blog_post.html">Continue reading...</a>
            
            	</div>
                <div class="cleaner"></div>
            </div>
        
       	  </div>
       	  <?php $__env->stopSection(); ?>