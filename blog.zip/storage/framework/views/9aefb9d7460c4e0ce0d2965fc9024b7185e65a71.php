 @extend('master')
 <?php $__env->startSection('main_content'); ?>

<div id="templatemo_content">

<?php $__currentLoopData = $all_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<div class="post_section">
        
    

  
  
  	<div class="post_date">
    	24<span>Oct</span>
	</div>
    
    <div class="post_content">
    	<h2><a href="<?php echo e(URL::to('/blog-detail/'.$blog->blog_id)); ?>"><?php echo e($blog->blog_title); ?></a></h2>
    	<strong>Author:</strong> <?php echo e($blog->admin_name); ?> | <strong>Category:</strong> <a href="<?php echo e(URL::to('/category-blog/'.$blog->category_id)); ?>"><?php echo e($blog->category_name); ?></a>
    <?php if($blog->blog_image): ?>
    	<a href="<?php echo e(asset($blog->blog_image)); ?>" target="_parent"><img src="<?php echo e(asset($blog->blog_image)); ?>" alt="image" /></a>
    <?php endif; ?>
    
    	<p><?php echo e($blog->short_description); ?></p>
   	  <a href="<?php echo e(URL::to('/blog-detail/'.$blog->blog_id)); ?>">58 Comments</a> | <a href="<?php echo e(URL::to('/blog-detail/'.$blog->blog_id)); ?>">Continue reading...</a>

	</div>
    <div class="cleaner"></div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
       	  <?php $__env->stopSection(); ?>