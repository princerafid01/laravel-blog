<?php $__env->startSection('category'); ?>

    <h4>Categories</h4>
    <ul class="templatemo_list">
    	<?php

    	 ?>
    	<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(URL::to('/category-blog/'.$category->category_id)); ?>"><?php echo e($category->category_name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>