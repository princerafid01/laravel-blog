<?php $__env->startSection('admin_main_content'); ?>
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">Library</a></li>
  <li class="active">Data</li>
</ol>
<table class="table"> 
	<caption></caption>
	<thead> 
		<tr> 
			<th>#</th> 
			<th>Category Name</th> 
			<th>Category Description</th> 
			<th>Publication status</th> 
		</tr> 
	</thead> 
	<tbody> 
		<?php 
			$all_category = DB::table('tbl_category')
							->get();
			$i = 1;
		?>
			<?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr> 
			<th scope="row"><?php echo e($i++); ?></th> 
			<td><?php echo e($category->category_name); ?></td> 
			<td><?php echo e($category->category_description); ?></td> 
			<td><?php echo e(($category->publication_status == 1) ? "Published" : "Unpublished"); ?> </td> 
		</tr> 
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody> 
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>