<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Foul extends Model
{
    public function searchOutput($blog)
    {
    	
    }
}
